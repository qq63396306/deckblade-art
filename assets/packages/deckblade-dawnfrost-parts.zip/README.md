# 晨霜 · 战斗骨架分件

游戏使用 dawnfrost-parts.png（104×124，透明背景）。dawnfrost-parts-8x.png 是最近邻放大版（832×992），两者均可直接喂给组装器。不要将预览图用作图集。

以 parts/parts.json 的 rect、pivot、end 放置各部件，不要裁掉单格的透明边：头、胸腹、上臂、前臂及握拳、腿甲、大腿以下的胫甲、脚靴和剑共 8 个有效件。cape 格全透明。头与脚朝右，剑柄为挂点，剑尖向右；远侧手脚由渲染器复用并压暗，不需另一套左右肢。

## 复现
安装 Pillow 后，在解压目录运行：

    python -I tools/assemble.py dawnfrost-parts.png parts/parts.json parts/poses.json rebuilt.png

parts/、tools/assemble.py 原样取自上游提交 5250bdfd0acf845479c2163b051be246ee5371e9。assembly-preview.png 是该命令的直接结果；预览器本身的固定画布会截到部分动作边缘。pose-check.gif 使用相同骨骼、部件绘制和层级，仅扩大画布并统一取景来展示完整动作。GIF 的示意帧时长不代表游戏技能时序。

已用 5 组、19 个上游姿势检查：stand 1、run 4、combo 6、fists 4、rising 4。未改任何游戏渲染代码，未在游戏客户端实装。
