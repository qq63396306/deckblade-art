# 16 位女性角色 · 战斗骨架分件
上游 8ab9dee 第二轮返工：红心只换头格（右侧脸、红唇、两只黑色粉芯兔耳）；赤鬃与夜蔷基于 d4705cb 的已确认站姿，各新增一张九格图集。全部站姿未改。余下 13 位分件保持原样。
每人九格。native 为 104×124 原生图，x8 为 832×992。使用 parts/parts.json 的格位、pivot、end；不要裁格内留白。check/ 为随包工具对各角色的固定画布检查图，pose-check.gif 是留白画布的 16 人总览，动作速度仅供美术验收。三位本轮相关角色共 57 个骨架姿势经过离线检查。未修改游戏代码。
复现：python -I tools/assemble.py native/queenheart.png parts/parts.json parts/poses.json rebuilt.png
